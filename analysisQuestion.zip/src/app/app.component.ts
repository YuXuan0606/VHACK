import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-angular-app-2';

  constructor(private router:Router){}

  submit(pageName: string): void {
    this.router.navigate([pageName]);
  }
  
}
