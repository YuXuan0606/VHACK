import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QuizComponent } from './quiz/quiz.component';
import { EventsComponent } from './events/events.component';
import { ForumComponent } from './forum/forum.component';

export const routes: Routes = [
  { path: 'quiz', component: QuizComponent },
  { path: 'events', component: EventsComponent },
  { path: 'forum', component: ForumComponent },
  { path: '', redirectTo: 'events', pathMatch: 'full' } 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }